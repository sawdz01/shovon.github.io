
<?php
if (!defined('IN_SCRIPT'))
    die("");

if (isset($_REQUEST["id"])) {
    $id = intval($_REQUEST["id"]);
    $this->ms_i($id);
} else {
    die("The listing ID isn't set.");
}


$listings = simplexml_load_file($this->data_file);
$blog_post = $listings->listing[$id];
$post_images = explode(",", $blog_post->images);
?>

<?php
$strLink = $this->post_link($listing_counter, $listing->title);
$blog_category_name = $this->show_category($blog_post->blog_category);

$domainname = $this->information->domainname;
?>

<?php
if (!defined('IN_SCRIPT'))
    die("");
?>



    <header id="top" class="amp-wp-header">
        <div>
            <a href="../">
                <h1 class="amp-site-title">
                    <?php echo $this->information->webname; ?>			</h1>
            </a>
        </div>
    </header>

<article class="amp-wp-article">
	<header class="amp-wp-article-header">
		<h1 class="amp-wp-title"><?php echo $blog_post->title; ?></h1>
			<div class="amp-wp-meta amp-wp-byline">
					<i class="fa fa-user-pluss"></i>
				<span class="amp-wp-author author vcard"><?php echo $blog_category_name; ?> </span> 
	</div>
<div class="amp-wp-meta amp-wp-posted-on">
	<time>
		<?php echo date($this->settings["website"]["date_format"], intval($blog_post->time)); ?>  </time>
</div>
	</header>

	<figure class="amp-wp-article-featured-image wp-caption">
	<amp-img width="1024" height="614" src="<?php if (file_exists("../uploaded_images/" . $post_images[0] . ".jpg")) echo "../uploaded_images/" . $post_images[0] . ".jpg"; ?>" 
class="attachment-large size-large wp-post-image amp-wp-enforced-sizes" alt="<?php echo $blog_post->title; ?>" ></amp-img>	</figure>

	<div class="amp-wp-article-content">
		<p  style="font-family:Courier New,Courier,monospace"><?php echo html_entity_decode($blog_post->description); ?></p>
	</div>

	<footer class="amp-wp-article-footer">
			<div class="amp-wp-meta amp-wp-tax-category">
		Categories: <a href="" rel="category tag"><?php echo $blog_category_name; ?></a>	</div>

		
	</footer>
</article>

<footer class="amp-wp-footer">
	<div>
		<h2> <?php echo $this->information->webname; ?>	</h2>
		<a href="#top" class="back-to-top">Back to top</a>
	</div>
</footer>
<?php
if (sizeof($post_images) > 1) {
    ?>
    <br/>

    <?php
    $images_counter = 0;

    for ($i = 0; $i < sizeof($post_images); $i++) {
        if ($images_counter % 4 == 0) {
            echo '<div class="row">';
        }

        if (trim($post_images[$i]) == "")
            continue;

        echo "<div class=\"col-md-4\">";

        echo "<a href=\"uploaded_images/" . $post_images[$i] . ".jpg\" rel=\"prettyPhoto[ad_gal]\">";

        echo "<img src=\"thumbnails/" . $post_images[$i] . ".jpg\" class=\"img-fluid\" alt=\"" . $blog_post->title . "\"/>";

        echo "</a>";

        echo "</div>";

        if (($images_counter + 1) % 4 == 0) {
            echo '</div>';
        }

        $images_counter++;
    }

    if ($images_counter % 4 != 0) {
        echo '</div>';
    }
    ?>

    <div class="clearfix"></div>

    <br/>
    <?php
}
?>





<?php
$this->Title($blog_post->title);
$this->MetaDescription($blog_post->description);
$this->MetaKeywords($blog_post->keywords);
$this->Canonical("" . $domainname . "index.php?page=post&id=" . $id . "");
?> 
</div>
</div>
</div>