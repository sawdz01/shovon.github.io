; <?php exit;?>

[login]
admin_user = "minar"
admin_password = "edaa7b93c058dd80e70930aec4817bb5"

[website]
seo_urls = "1"
date_format = "F jS, Y"
results_per_page = "6"
admin_email = "minarshovon909@gmail.com"
use_captcha_images = "0"
time_zone = "Bangladesh/Dhaka"
show_results = ""
only_one_per_ip = ""
accent_color = ""
font_name = ""
font_size = ""

[email]
smtp_server = "localhost"
smtp_user = "minarshovon909@gmail.com"
smtp_password = "needwebsite"
smtp_port = "25"

