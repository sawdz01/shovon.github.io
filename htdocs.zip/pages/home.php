<header class="page-header www-header"  style="background-color:rgb(0,176,240);">
    <div class="container clr page-header-inner">
        <h1 style="color:white"  class="tagline1 cl" itemprop="headline"><?php echo $this->information->tagline; ?></h1>
    </div><!-- .page-header-inner -->
</header><!-- .page-header -->
<div id="content-wrap" class="container clr">
    <div id="primary" class="content-area clr">
        <div id="content" class="site-content clr">
            <div id="blog-entries" class="entries clr">
                <?php
                if (!defined('IN_SCRIPT'))
                    die("");
                $domainname = $this->information->domainname;
                ?>
                <?php
                $PageSize = intval($this->settings["website"]["results_per_page"]);

                if (!isset($_REQUEST["num"])) {
                    $num = 1;
                } else {
                    $num = $_REQUEST["num"];
                    $this->ms_i($num);
                }

                $listings = simplexml_load_file($this->data_file);

//reversing the array with the news to show the latest first
                $xml_results = array();
                foreach ($listings->listing as $xml_element)
                    $xml_results[] = $xml_element;
                $xml_results = array_reverse($xml_results);
//end reversing the order of the array

                $shown_listings = 1;
                $iTotResults = 0;
                $listing_counter = sizeof($xml_results);

                foreach ($xml_results as $listing) {
                    $listing_counter--;

//refine search
                    if (isset($_REQUEST["only_picture"]) && $_REQUEST["only_picture"] == 1) {
                        if (trim($listing->images) == "")
                            continue;
                    }

                    if (isset($_REQUEST["keyword_search"]) && trim($_REQUEST["keyword_search"]) != "") {
                        if
                        (
                                stripos($listing->title, $_REQUEST["keyword_search"]) === false &&
                                stripos($listing->description, $_REQUEST["keyword_search"]) === false
                        ) {
                            continue;
                        }
                    }
//end refine search


                    if ($iTotResults >= ($num - 1) * $PageSize && $iTotResults < $num * $PageSize) {
                        $images = explode(",", $listing->images);

                        $strLink = $this->post_link($listing_counter, $listing->title);
                        ?>







                        <article id="post-75" class="blog-entry clr large-entry col-1 post-75 post type-post status-publish format-standard has-post-thumbnail hentry category-uncategorized entry has-media">
                            <div class="blog-entry-inner clr">
                                <div class="image-hover">
                                    <a href="<?php echo $strLink; ?>" class="thumbnail-link" title="<?php echo $listing->title; ?>" >
                                        <img  title="<?php echo $listing->title; ?>"  width="2048" height="1024" src="<?php
                                        if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                                            echo "images/image.png";
                                        else
                                            echo "thumbnails/" . $images[0] . ".jpg";
                                        ?>" class="attachment-full size-full wp-post-image" alt="<?php echo $listing->title; ?>" 
                                              itemprop="image" srcset="<?php
                                              if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                                                  echo "images/image.png";
                                              else
                                                  echo "thumbnails/" . $images[0] . ".jpg";
                                              ?> 2048w, <?php
                                              if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                                                  echo "images/image.png";
                                              else
                                                  echo "thumbnails/" . $images[0] . ".jpg";
                                              ?> 300w, <?php
                                              if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                                                  echo "images/image.png";
                                              else
                                                  echo "thumbnails/" . $images[0] . ".jpg";
                                              ?> 768w, <?php
                                              if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                                                  echo "images/image.png";
                                              else
                                                  echo "thumbnails/" . $images[0] . ".jpg";
                                              ?> 1024w" sizes="(max-width: 2048px) 100vw, 2048px" />			
                                        <span class="overlay"></span>
                                    </a>
                                </div><!-- .thumbnail -->
                                <header class="blog-entry-header clr">
                                    <h1 class="blog-entry-title entry-title">
                                        <a href="<?php echo $strLink; ?>" class="custom-text" title="<?php echo $listing->title; ?>" rel="bookmark"><?php echo $listing->title; ?></a>
                                   <a href="amp/<?php echo $strLink; ?>" class="custom-text tooltip pull-right" title="<?php echo $listing->title; ?>" rel="bookmark"><img alt="amp image of <?php echo $listing->title; ?>" src="amp/amp.jpg" style="width:25px">  
                                       <span class="tooltiptext" style="font-size:10px">Click To Load Faster</span>   </a>
                               </h1><!-- .blog-entry-title -->
                                </header><!-- .blog-entry-header -->
                                <ul class="meta clr">
                                    <li  class="meta-date text-p" itemprop="datePublished"><i class="icon-clock text-p"></i>        <?php echo date($this->settings["website"]["date_format"], intval($listing->time)); ?></li>
                                    <li  class="meta-comments text-p"><i class="icon-tag"></i><?php echo $this->show_category($listing->blog_category); ?></li>
                                    <li   class="meta-author text-p" itemprop="name"><i class="icon-user"></i>minar</li>
                                </ul>
                                <div class="blog-entry-summary clr" itemprop="text">
                                    <p  style="text-align: justify;color:black;font-family:Courier New,Courier,monospace">
                                        <?php echo $this->text_words(strip_tags($listing->description), 70); ?>
                                    </p>
                                </div><!-- .blog-entry-summary --><div class="blog-entry-readmore clr">
                                    <a href="<?php echo $strLink; ?>"class="text-p-a" title="<?php echo $listing->title; ?>">Continue Reading<i class="fa fa-angle-right"></i></a>
                                </div><!--  -->
                            </div><!-- .blog-entry-inner -->
                        </article><!-- #post-## -->    

                        <?php
                        if ($shown_listings % 3 == 0)
                            echo "<div class=\"clearfix\"></div>";
                        $shown_listings++;
                    }

                    $iTotResults++;
                }
                ?>


                <?php
                $this->Title($this->information->default_title);
                $this->MetaDescription($this->information->default_description);
                $this->MetaKeywords($this->information->default_keywords);
                $this->Canonical("" . $domainname . "index.php?");
                ?>
                <div class="clearfix"></div>

                <div class="oceanwp-pagination clr">
                    <?php
                    $strSearchString = "";

                    foreach ($_POST as $key => $value) {
                        if ($key != "num" && $value != "") {
                            $strSearchString .= $key . "=" . $value . "&";
                        }
                    }

                    foreach ($_GET as $key => $value) {
                        if ($key != "num" && $value != "") {
                            $strSearchString .= $key . "=" . $value . "&";
                        }
                    }


                    if (ceil($iTotResults / $PageSize) > 1) {
                        echo '<ul class="page-numbers" role="navigation">';



                        $inCounter = 0;

                        if ($num > 2) {
                            echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=1\">First</a></li>";

                            echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=" . ($num - 1) . "\"> Previous</a></li>";
                        }

                        $iStartNumber = $num - 2;


                        if ($iStartNumber < 1) {
                            $iStartNumber = 1;
                        }

                        for ($i = $iStartNumber; $i <= ceil($iTotResults / $PageSize); $i++) {
                            if ($inCounter >= 5) {
                                break;
                            }

                            if ($i == $num) {
                                echo "<li><a class=\" page-numbers\"><b>" . $i . "</b></a></li>";
                            } else {
                                echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=" . $i . "\">" . $i . "</a></li>";
                            }


                            $inCounter++;
                        }

                        if (($num + 1) < ceil($iTotResults / $PageSize)) {
                            echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=" . ($num + 1) . "\"> Next</b></a></li>";

                            echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=" . (ceil($iTotResults / $PageSize)) . "\">Last </a></li>";
                        }

                        echo '</ul>';
                    }



                    if ($iTotResults == 0) {
                        ?>
                        <div class="col-md-12">
                            <i><?php echo $this->texts["no_results"]; ?></i>
                        </div>
                        <?php
                    }
                    ?>          
                </div>

            </div><!-- #blog-entries -->

        </div><!-- #content -->
    </div><!-- #primary -->