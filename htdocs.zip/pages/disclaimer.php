<header class="page-header www-header">
                        <div class="container clr page-header-inner">
                            <h1 style="color:white"  class="page-header-title clr" itemprop="headline" align="left">Disclaimer</h1>
                        </div><!-- .page-header-inner -->
                    </header><!-- .page-header -->
                    <div id="content-wrap" class="container clr">
                        <div id="primary" class="content-area clr">
                            <div id="content" class="site-content clr">
                                <div id="blog-entries" class="entries clr"><?php echo $this->information->disclaimer;?>
    <?php

    $domainname = $this->information->domainname;
$this->Title($this->texts["disclaimer"]);
$this->MetaDescription("qwertyu");
$this->MetaKeywords("qwertyu");
                $this->Canonical("".$domainname."index.php?page=disclaimer");
?>

           </div><!-- #blog-entries -->

                            </div><!-- #content -->
                        </div><!-- #primary -->