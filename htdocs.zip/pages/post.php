
<?php
if (!defined('IN_SCRIPT'))
    die("");

if (isset($_REQUEST["id"])) {
    $id = intval($_REQUEST["id"]);
    $this->ms_i($id);
} else {
    die("The listing ID isn't set.");
}


$listings = simplexml_load_file($this->data_file);
$blog_post = $listings->listing[$id];
$post_images = explode(",", $blog_post->images);
?>

<?php
    $strLink = $this->post_link($listing_counter, $listing->title);
$blog_category_name = $this->show_category($blog_post->blog_category);

    $domainname = $this->information->domainname;
?>

<?php
if (!defined('IN_SCRIPT'))
    die("");
?>

    <header class="page-header www-header">


        <div class="container clr page-header-inner">


            <h1 class="page-header-title clr" style="color:white" itemprop="headline" align="left">Blog</h1>



            <nav role="navigation" aria-label="Breadcrumbs" class="site-breadcrumbs clr" itemprop="breadcrumb">
                <ul class="trail-items" itemscope itemtype="http://schema.org/BreadcrumbList" align="right">
                    <meta name="numberOfItems" content="6" />
                    <meta name="itemListOrder" content="Ascending" />
                    <li style="color:white" class="trail-item trail-begin" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                        <a href="../index.php" rel="home" aria-label="Home">
                            <span style="color:white"  itemprop="name"><span class="icon-home"></span>
                                <span class="breadcrumb-home has-icon">Home</span></span></a>  > 
                        <?php echo $blog_category_name; ?> >  
                        <?php echo $blog_post->title; ?>
                    </li></ul></nav>
        </div>



    </header>
    <div id="content-wrap" class="container clr">
        <div id="primary" class="content-area clr">
            <div id="content" class="site-content clr">
                <div id="blog-entries" class="entries clr">	
                    <div class="blog-detail mt-30">
                        <div class="b-det-img">
                            <a href="" class="post-img-link">
                                <img  border="0" 
                                      src="<?php if (file_exists("uploaded_images/" . $post_images[0] . ".jpg")) echo "uploaded_images/" . $post_images[0] . ".jpg"; ?>">
                            </a>
                        </div><br>
                        <div class="det-content">
                            <header class="blog-entry-header clr">
                                <h1 class="blog-entry-title entry-title">
                                    <?php echo $blog_post->title; ?> <!-- .blog-entry-title -->
                            </header><!-- .blog-entry-header -->
                            <div class="det-meta">

                                <a href="#" class="text-p">
                                    <i class="fa fa-calendar"></i>
                                    <?php echo date($this->settings["website"]["date_format"], intval($blog_post->time)); ?>       
                                </a>
                                <a href="#"class="text-p">
                                    <i class="fa fa-tags"></i>
                                    <?php echo $blog_category_name; ?>      </a> <a class="text-p"href="#"><i class="icon-user-follow"></i> Minar</a>
                            </div>
                            <p style="font-family:Courier New,Courier,monospace"><?php echo html_entity_decode($blog_post->description); ?></p>
                        </div></div>
                    <?php
                    if (sizeof($post_images) > 1) {
                        ?>
                        <br/>

                        <?php
                        $images_counter = 0;

                        for ($i = 0; $i < sizeof($post_images); $i++) {
                            if ($images_counter % 4 == 0) {
                                echo '<div class="row">';
                            }

                            if (trim($post_images[$i]) == "")
                                continue;

                            echo "<div class=\"col-md-4\">";

                            echo "<a href=\"uploaded_images/" . $post_images[$i] . ".jpg\" rel=\"prettyPhoto[ad_gal]\">";

                            echo "<img src=\"thumbnails/" . $post_images[$i] . ".jpg\" class=\"img-fluid\" alt=\"" . $blog_post->title . "\"/>";

                            echo "</a>";

                            echo "</div>";

                            if (($images_counter + 1) % 4 == 0) {
                                echo '</div>';
                            }

                            $images_counter++;
                        }

                        if ($images_counter % 4 != 0) {
                            echo '</div>';
                        }
                        ?>

                        <div class="clearfix"></div>

                        <br/>
                        <?php
                    }
                    ?>





                <?php
                $this->Title($blog_post->title);
                $this->MetaDescription($blog_post->description);
                $this->MetaKeywords($blog_post->keywords);
                $this->Canonical("" . $domainname . "index.php?page=post&id=" . $id . "");
                ?> 
            </div>
        </div>
    </div>