<?php
if (!defined('IN_SCRIPT'))
    die("");
?>

<?php
if (isset($_REQUEST["category"])) {
    $this->check_category_id($_REQUEST["category"]);

    $category = str_replace("-", ".", trim($_REQUEST["category"]));

    $category_name = $this->show_category($category);
    $web_name = $this->information->webname
    ?>
    <header class="page-header www-header">


        <div class="container clr page-header-inner">


            <h1 class="page-header-title clr" style="color:white"  itemprop="headline" align="left">Post category:<?php echo $category_name; ?></h1>

            <nav role="navigation" aria-label="Breadcrumbs" class="site-breadcrumbs clr" itemprop="breadcrumb">
                <ul class="trail-items" itemscope itemtype="http://schema.org/BreadcrumbList" align="right">
                    <meta name="numberOfItems" content="6" />
                    <meta name="itemListOrder" content="Ascending" />
                    <li style="color:white"  class="trail-item trail-begin" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                        <a href="../index.php" rel="home" aria-label="Home">
                            <span  style="color:white"  itemprop="name"><span class="icon-home"></span>
                                <span class="breadcrumb-home has-icon">Home</span></span></a> >     <?php echo $category_name; ?>               
                    </li></ul></nav>
        </div>



    </header>
    <div id="content-wrap" class="container clr">
        <div id="primary" class="content-area clr">
            <div id="content" class="site-content clr">
                <div id="blog-entries" class="entries clr">

                    <?php
    $domainname = $this->information->domainname;
                    $this->Title($category_name . " - " . $web_name . "");
                    $this->MetaDescription("Latest blog posts and information about " . $category_name . " -" . $web_name . "");
                    $this->MetaKeywords("" . $category_name . "," . $web_name . "");
                $this->Canonical("".$domainname."index.php?page=posts&category=" . $category. "");
                }
                ?>


<?php
$PageSize = intval($this->settings["website"]["results_per_page"]);

if (!isset($_REQUEST["num"])) {
    $num = 1;
} else {
    $num = $_REQUEST["num"];
    $this->ms_i($num);
}

$listings = simplexml_load_file($this->data_file);

//reversing the array with the news to show the latest first
$xml_results = array();
foreach ($listings->listing as $xml_element) {
    $xml_results[] = $xml_element;
}
$xml_results = array_reverse($xml_results);
//end reversing the order of the array

$shown_listings = 1;
$iTotResults = 0;
$listing_counter = sizeof($xml_results);

foreach ($xml_results as $listing) {
    $listing_counter--;

    //refine search
    if (isset($_REQUEST["only_picture"]) && $_REQUEST["only_picture"] == 1) {
        if (trim($listing->images) == "")
            continue;
    }

    if (isset($_REQUEST["keyword_search"]) && trim($_REQUEST["keyword_search"]) != "") {
        if
        (
                stripos($listing->title, $_REQUEST["keyword_search"]) === false &&
                stripos($listing->description, $_REQUEST["keyword_search"]) === false
        ) {
            continue;
        }
    }

    if (isset($category) && $listing->blog_category != $category)
        continue;

    //end refine search


    if ($iTotResults >= ($num - 1) * $PageSize && $iTotResults < $num * $PageSize) {

        $images = explode(",", $listing->images);

        $strLink = $this->post_link($listing_counter, $listing->title);
        ?>

                        <article id="post-75" class="blog-entry clr large-entry col-1 post-75 post type-post status-publish format-standard has-post-thumbnail hentry category-uncategorized entry has-media">
                            <div class="blog-entry-inner clr">
                                <div class="image-hover">
                                    <a href="<?php echo $strLink; ?>" class="thumbnail-link" title="<?php echo $listing->title; ?>" >
                                        <img  title="<?php echo $listing->title; ?>"  width="2048" height="1024" src="<?php
                        if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                            echo "images/image.png";
                        else
                            echo "thumbnails/" . $images[0] . ".jpg";
                        ?>" class="attachment-full size-full wp-post-image" alt="<?php echo $listing->title; ?>" 
                                              itemprop="image" srcset="<?php
                if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                    echo "images/image.png";
                else
                    echo "thumbnails/" . $images[0] . ".jpg";
                ?> 2048w, <?php
                                        if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                                            echo "images/image.png";
                                        else
                                            echo "thumbnails/" . $images[0] . ".jpg";
                                        ?> 300w, <?php
                                              if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                                                  echo "images/image.png";
                                              else
                                                  echo "thumbnails/" . $images[0] . ".jpg";
                                              ?> 768w, <?php
                                              if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
                                                  echo "images/image.png";
                                              else
                                                  echo "thumbnails/" . $images[0] . ".jpg";
                                              ?> 1024w" sizes="(max-width: 2048px) 100vw, 2048px" />			
                                        <span class="overlay"></span>
                                    </a>
                                </div><!-- .thumbnail -->
                                <header class="blog-entry-header clr">
                                    <h1 class="blog-entry-title entry-title">
                                        <a href="<?php echo $strLink; ?>" class="custom-text" title="<?php echo $listing->title; ?>" rel="bookmark"><?php echo $listing->title; ?></a>
                                    </h1><!-- .blog-entry-title -->
                                </header><!-- .blog-entry-header -->
                                <!-- .blog-entry-header -->
                                <ul class="meta clr">
                                    <li class="meta-date text-p" itemprop="datePublished"><i class="icon-clock"></i>        <?php echo date($this->settings["website"]["date_format"], intval($listing->time)); ?></li>
                                    <li class="meta-comments text-p"><i class="icon-tag"></i><?php echo $this->show_category($listing->blog_category); ?></li>
                                    <li class="meta-author text-p" itemprop="name"><i class="icon-user"></i>minar</li>
                                </ul>
                                <div class="blog-entry-summary clr" itemprop="text">
                                    <p style="color: black;font-family:Courier New,Courier,monospace">
        <?php echo $this->text_words(strip_tags($listing->description), 70); ?>
                                    </p>
                                </div><!-- .blog-entry-summary --><div class="blog-entry-readmore clr">
                                    <a href="<?php echo $strLink; ?>" title="Continue Reading" class="text-p-a">Continue Reading<i class="fa fa-angle-right"></i></a>
                                </div><!-- .blog-entry-readmore -->
                            </div><!-- .blog-entry-inner -->
                        </article><!-- #post-## -->    



        <?php
        if ($shown_listings % 3 == 0)
            echo "<div class=\"clearfix\"></div>";
        $shown_listings++;
    }

    $iTotResults++;
}
?>
                <div class="clearfix"></div>	

                <div class="oceanwp-pagination clr">
                <?php
                $strSearchString = "";

                foreach ($_POST as $key => $value) {
                    if ($key != "num" && $value != "") {
                        $strSearchString .= $key . "=" . $value . "&";
                    }
                }

                foreach ($_GET as $key => $value) {
                    if ($key != "num" && $value != "") {
                        $strSearchString .= $key . "=" . $value . "&";
                    }
                }


                if (ceil($iTotResults / $PageSize) > 1) {
                    echo '<ul class="page-numbers" role="navigation">';



                    $inCounter = 0;

                    if ($num > 2) {
                        echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=1\">First</a></li>";

                        echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=" . ($num - 1) . "\"> Previous</a></li>";
                    }

                    $iStartNumber = $num - 2;


                    if ($iStartNumber < 1) {
                        $iStartNumber = 1;
                    }

                    for ($i = $iStartNumber; $i <= ceil($iTotResults / $PageSize); $i++) {
                        if ($inCounter >= 5) {
                            break;
                        }

                        if ($i == $num) {
                            echo "<li><a class=\" page-numbers\"><b>" . $i . "</b></a></li>";
                        } else {
                            echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=" . $i . "\">" . $i . "</a></li>";
                        }


                        $inCounter++;
                    }

                    if (($num + 1) < ceil($iTotResults / $PageSize)) {
                        echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=" . ($num + 1) . "\"> Next</b></a></li>";

                        echo "<li><a class=\" page-numbers\" href=\"index.php?" . $strSearchString . "num=" . (ceil($iTotResults / $PageSize)) . "\">Last </a></li>";
                    }

                    echo '</ul>';
                }



                if ($iTotResults == 0) {
                    ?>
                        <div class="col-md-12">
                            <i><?php echo $this->texts["no_results"]; ?></i>
                        </div>
                        <?php
                    }
                    ?>          
                </div>


            </div><!-- #blog-entries -->

        </div><!-- #content -->
    </div><!-- #primary -->