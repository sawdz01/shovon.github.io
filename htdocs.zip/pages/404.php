<header class="page-header www-header">
    <div class="container clr page-header-inner">
        <h1  style="color:white"  class="page-header-title clr" itemprop="headline" align="left">Error </h1>
    </div><!-- .page-header-inner -->
</header><!-- .page-header -->
<div id="content-wrap" class="container clr">
    <div id="primary" class="content-area clr">
        <div id="content" class="site-content clr">
            <div id="blog-entries" class="entries clr">

                <h1 class="text-danger" >404 NOT FOUND</h1><aside id="search-2" class="widget widget_search"><br>
                    <h1>Back to <a href="../index.php?" class="text-info"> Home</a></h1>
                    <br><br>

                    <div id="search-2" class="sidebar-box widget_search clr">
                        <form method="get" class="searchform" id="searchform" action="../index.php?page=results">
                            <input type="hidden" name="page" value="results"/>
                            <input type="hidden" name="proceed_search" value="1"/>
                            <input type="search" class="border-in" placeholder="<?php echo $this->texts["keyword"]; ?>"
                                   value="<?php if (isset($_REQUEST["keyword_search"])) echo stripslashes($_REQUEST["keyword_search"]); ?>" name="keyword_search" title="Search for:" >
                        </form>
                    </div>
                </aside><br><br><br><br>


                <?php
                $domainname = $this->information->domainname;
                $this->Title("ERROR 404");
                $this->MetaDescription("Error 404 Page ");
                $this->MetaKeywords("Error 404 Page ");
                $this->Canonical("" . $domainname . "index.php?page=404");
                ?>

            </div><!-- #blog-entries -->

        </div><!-- #content -->
    </div><!-- #primary -->