
    <header id="top" class="amp-wp-header">
        <div>
            <a href="http://localhost/wordpress/">
                <span class="amp-site-title">
                    <?php echo $this->information->webname; ?>			</span>
            </a>
        </div>
    </header>