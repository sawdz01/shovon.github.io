<header id="site-header" class="vertical-center  has-social  www-nav  vertical-header is-active has-shadow vh-center-logo clr" data-height="0" itemscope="itemscope" itemtype="http://schema.org/Header">
    <div id="site-header-inner" class="clr">
        <div id="site-logo" class="clr" itemscope itemtype="http://schema.org/Brand">
            <div id="site-logo-inner" class="clr">
                <a href="../index.php" style="padding-left: 10px;color:rgb(228, 102, 90)" rel="home" class="site-title site-logo-text"><?php echo $this->information->webname; ?></a>
            </div><!-- #site-logo-inner -->
        </div><!-- #site-logo -->
        <div id="site-navigation-wrap" class="clr">
            <nav id="site-navigation" class="navigation main-navigation clr" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
                <ul id="menu-menu-1" class="main-menu dropdown-menu">
                    <li id="menu-item-4" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-4">
                        <a href="../index.php" class="menu-link">
                            <span class="custom-text">Home</span>
                        </a>
                    </li>
                    <li id="menu-item-5" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5">
                        <a href="../page-contact.html" class="menu-link">
                            <span class="custom-text"><?php echo $this->texts["contact"]; ?></span>
                        </a>
                    </li>
                    <li id="menu-item-5" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5">
                        <a href="../page-about.html" class="menu-link">
                            <span class="custom-text"><?php echo $this->texts["about"]; ?></span>
                        </a>
                    </li>
                </ul>
            </nav><!-- #site-navigation -->
        </div>
        <div id="vertical-searchform" class="header-searchform-wrap clr">
            <form method="get" action="../index.php?page=results" class="header-searchform">
                <input type="hidden" name="page" value="results"/>
        <input type="hidden" name="proceed_search" value="1"/>
       <input type="search" placeholder="<?php echo $this->texts["keyword"]; ?>" name="keyword_search"
                       value="<?php if (isset($_REQUEST["keyword_search"])) echo stripslashes($_REQUEST["keyword_search"]); ?>" name="keyword_search" title="Search for:">
                <button class="search-submit"><i class="custom-text icon-magnifier"></i></button>
                <div class="search-bg"></div>
            </form>
        </div>          
<div class="oceanwp-social-menu clr simple-social">

	<div class="social-menu-inner clr">

		
			<ul>

				<li class="oceanwp-twitter"><a href="http://yhh" target="_blank"><span class="fa fa-twitter"></span></a></li><li class="oceanwp-facebook"><a href="http://hyhhyh" target="_blank"><span class="fa fa-facebook"></span></a></li><li class="oceanwp-googleplus"><a href="http://hhhhhhhy" target="_blank"><span class="fa fa-google-plus"></span></a></li><li class="oceanwp-pinterest"><a href="http://gtfgrgtgrt" target="_blank"><span class="fa fa-pinterest-p"></span></a></li><li class="oceanwp-dribbble"><a href="http://ujyu" target="_blank"><span class="fa fa-dribbble"></span></a></li>
			</ul>

		
	</div>

</div>
        
    
        <div class="oceanwp-mobile-menu-icon clr mobile-left">
            <a href="#" class="mobile-menu">
                <i class="fa fa-bars custom-text" style="font-size: 30px"></i>
                <span class="oceanwp-text"></span>
            </a>
        </div>
        <a href="#" class="vertical-toggle custom-text">
            <div class="hamburger hamburger--spin">
                <div class="hamburger-box ">
                    <div  class="hamburger-inner custom-text"></div>
                </div>
            </div>
        </a>
    </div>
</header>