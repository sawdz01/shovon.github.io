
<div id="search-2" class="sidebar-box widget_search clr">
    <form method="get" class="searchform" id="searchform" action="../index.php?page=results">
        <input type="hidden" name="page" value="results"/>
        <input type="hidden" name="proceed_search" value="1"/>
        <input type="search" class="border-in" placeholder="<?php echo $this->texts["keyword"]; ?>"
              value="<?php if (isset($_REQUEST["keyword_search"])) echo stripslashes($_REQUEST["keyword_search"]); ?>" name="keyword_search" title="Search for:" >
    </form>
</div>