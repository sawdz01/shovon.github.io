<footer class="amp-wp-footer">
	<div>
		<h2>qwertyui</h2>
		<p>
			<a href="https://wordpress.org/">
				Powered by WordPress			</a>
		</p>
		<a href="#top" class="back-to-top">Back to top</a>
	</div>
</footer>