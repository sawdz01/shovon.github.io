<?php
$show_add_form = true;

class SimpleXMLExtended extends SimpleXMLElement {

    public function addChildWithCDATA($name, $value = NULL) {
        $new_child = $this->addChild($name);

        if ($new_child !== NULL) {
            $node = dom_import_simplexml($new_child);
            $no = $node->ownerDocument;
            $node->appendChild($no->createCDATASection($value));
        }

        return $new_child;
    }

}

if (isset($_REQUEST["proceed_save"])) {
    ///images processing
    $str_images_list = "";
    $limit_pictures = 25;
    $path = "../";

    $ini_array = parse_ini_file("../config.php", true);
    $image_quality = $ini_array["website"]["image_quality"];
    $max_image_width = $ini_array["website"]["max_image_width"];

    include("include/images_processing.php");
    ///end images processing
    $listings = simplexml_load_file($this->email_file, 'SimpleXMLExtended', LIBXML_NOCDATA);
    $listing = $listings->addChild('listing');
    $listing->addChild('time', time());
    $listing->addChild('title', stripslashes($_POST["title"]));
    $article_content = str_replace("&nbsp;", " ", $article_content);

    $listings->asXML($this->email_file);
    ?>
    <h3  class="custom-text-p"><?php echo $this->texts["email_1"]; ?> </h3>

    <br/>
    <br/>
    <br/>
    <?php
    $show_add_form = false;
}



if ($show_add_form) {
    ?>

    <h3 class="custom-text-p">
        <?php echo $this->texts["email_2"]; ?> 
    </h3>        <div class="floating-box header-searchform-wrap ">
        <form  action="/" method="post" enctype="multipart/form-data">
            <input type="hidden" name="proceed_save" value="1"/>



            <input type="email" name="title" class="border-in" required  value="">

            <div class="clearfix"></div>

            By Signing Up to our news letter ,You agreed with our <a href="page-terms.html">terms & Condition</a>
            <div class="clearfix"></div>
            <br/>
            <button type="submit" class="btn www-top pull-right"> <?php echo $this->texts["submit"]; ?> </button>
            <div class="clearfix"></div>
            <br/><br/>
        </form>

    </div>
    <?php
}
?>