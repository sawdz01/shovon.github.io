<?php
	if
	(
		$this->information->blog_logo!=""
		&&
		file_exists("thumbnails/".$this->information->blog_logo.".jpg")	
	)
	{
		echo '<link rel="icon" href="thumbnails/'.$this->information->blog_logo.'.jpg" >';
	}
	

	
	?>