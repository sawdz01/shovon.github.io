<div id="meta-2" class="sidebar-box widget_meta clr ">
                                    <h4 class="custom-text-p">Categories</h4>
                                                                       	
                                    <ul><?php
$blog_categories = file_get_contents('include/categories.php');

$arrCategories = explode("\n", trim($blog_categories));

foreach($arrCategories as $strCategory)
{
	list($key,$value)=explode(". ",$strCategory);
	
	$category_link = $this->category_link($key, $value);
	
	echo '<a href="'.$category_link.'" title="'.$value.'"><li class="custom-text">'.$value.'</li></a><hr>';
}
?></ul>
</div>