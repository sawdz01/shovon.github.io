  <div id="meta-2" class="sidebar-box widget_meta clr">
                                    <h4 class="custom-text-p">Latest Posts</h4>	
                                    <ul><?php
$listings = simplexml_load_file($this->data_file);

//reversing the array with the news to show the latest first
$xml_results = array();
foreach ($listings->listing as $xml_element) $xml_results[] = $xml_element;
$xml_results = array_reverse($xml_results); 
//end reversing the order of the array

$iTotResults = 0;
$listing_counter=sizeof($xml_results);
$number_posts=0; 

foreach ($xml_results as $listing)
{
	if($number_posts>=5) break;
	
	$listing_counter--; 
  
	$strLink=$this->post_link($listing_counter,$listing->title);
?><a href="<?php echo $strLink;?>" title="<?php echo $listing->title;?>">
<li class="custom-text">
    
		
			<?php
			if(trim($listing->images) != "")
			{
				$post_images=explode(",",$listing->images);
				
				if(file_exists("thumbnails/".$post_images[0].".jpg"))
				{
					echo '<img src="thumbnails/'.$post_images[0].'.jpg" alt="'.$listing->title.'" style="width:50px"/>';
				} 
                                
			}
			?>
		
			<?php echo $listing->title;?>     <a style="padding-left"10px"  href="amp/<?php echo $strLink; ?>" class="pull-right custom-text tooltip" title="<?php echo $listing->title; ?>" rel="bookmark"><img alt="amp image of <?php echo $listing->title; ?>" src="amp/amp.jpg" style="width:25px">  
                                       <span class="tooltiptext" style="font-size:10px">Click To Load Faster</span>   </a>
			<hr>
                
			
		
		
	</li></a>
<?php
	$number_posts++;
}
?> 
        
        
        
 </ul>
                                </div> 