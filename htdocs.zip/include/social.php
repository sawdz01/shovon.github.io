
   <?php
	if
	(
		$this->information->intro_background!=""
		&&
		file_exists("thumbnails/".$this->information->intro_background.".jpg")	
	)
	{
		echo '<meta property="og:image" content="thumbnails/'.$this->information->intro_background.'.jpg" >';
	}
	

	
	?>
