
<?php
$PageSize = intval(6);

if (!isset($_REQUEST["num"])) {
    $num = 1;
} else {
    $num = $_REQUEST["num"];
    $this->ms_i($num);
}

$listings = simplexml_load_file($this->post_file);

//reversing the array with the news to show the latest first
$xml_results = array();
foreach ($listings->listing as $xml_element)
    $xml_results[] = $xml_element;
$xml_results = array_reverse($xml_results);
//end reversing the order of the array

$shown_listings = 1;
$iTotResults = 0;
$listing_counter = sizeof($xml_results);

foreach ($xml_results as $listing) {
    $listing_counter--;

//refine search
    if (isset($_REQUEST["only_picture"]) && $_REQUEST["only_picture"] == 1) {
        if (trim($listing->images) == "")
            continue;
    }

    if (isset($_REQUEST["keyword_search"]) && trim($_REQUEST["keyword_search"]) != "") {
        if
        (
                stripos($listing->title, $_REQUEST["keyword_search"]) === false &&
                stripos($listing->description, $_REQUEST["keyword_search"]) === false
        ) {
            continue;
        }
    }


    if ($iTotResults >= ($num - 1) * $PageSize && $iTotResults < $num * $PageSize) {
        $images = explode(",", $listing->images);

        $strLink = $this->post_link($listing_counter, $listing->title);
        ?>

        <article  class="col-md-3 col-sm-6" style="padding-top: 10px;padding-bottom: 10px;">
            <div  style="background-color: #4d5b74;height: 300px ">
                <a href="a<?php echo $strLink; ?>" title="<?php echo $listing->title; ?>" >
                    <img src="<?php if ($images[0] == "" || !file_exists("thumbnails/" . $images[0] . ".jpg"))
            echo "images/image.png";
        else
            echo "thumbnails/" . $images[0] . ".jpg";
        ?>" value="<?php echo $this->texts["search"]; ?>" alt='<?php echo $listing->title; ?>' style="width: 100%;height:90px" />							
                </a>

                <header class=" page-header">

                    <h3 style="color:white" align="center" >
                        <a href="a<?php echo $strLink; ?>" title="<?php echo $listing->title; ?>" style="color: white" rel="bookmark">
        <?php echo $listing->title; ?>
                        </a>
                    </h3>
<!-- .entry-meta -->
                </header><!-- .entry-header -->

                <div class="entry-content">

                    <p style="color:white" align="center"> <?php echo $this->text_words(strip_tags($listing->description), 10); ?>	</p><br>
                </div><!-- .entry-content -->

            </div>
        </article>


        <?php
    }

    $iTotResults++;
}
?>
<?php
$this->Title($this->information->default_title);
$this->MetaDescription($this->information->default_description);
$this->MetaKeywords($this->information->default_keywords);
?>
<div class="clearfix"></div>
         