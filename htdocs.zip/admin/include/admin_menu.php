<?php
if (!defined('IN_SCRIPT'))
    die("");
?>

<?php
$this->SetAdminHeader($this->texts["config_options"]);
?>


    <?php
    $ini_array = parse_ini_file("../config.php", true);

    if (isset($_REQUEST["set_default"]) && $_REQUEST["set_default"] != "") {
        $ini_array["website"]["accent_color"] = "";
        $this->write_ini_file("../config.php", $ini_array);
    }
    $this->write_ini_file("../config.php", $ini_array);
    
    ?><aside class="main-sidebar">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="../dist/img/avatar04.png" class="img-circle" alt="User Image">
                        </div>
                        <div class="pull-left info">
                            <p><?php echo $ini_array["login"]["admin_user"]; ?></p>
                            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                        </div>
                    </div>
                    <!-- search form -->
                    <form action="../index.php?" method="get" class="sidebar-form">
                        <div class="input-group">                       
                            <form action="../index.php" method="post">
                                <input type="hidden" name="page" value="results"/>
                                <input type="hidden" name="proceed_search" value="1"/>
                                <input class="form-control"  required name="keyword_search" placeholder="" value=""/>

                            <span class="input-group-btn">
                                <input type="submit"   id="search-btn" class="btn btn-flat" value="search"/>
                            </span>
                            </form>
                          
                        </div>
                    </form>
                    <ul class="sidebar-menu " data-widget="tree">

                        <li>
                            <a href="index.php?">
                                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a href="index.php?page=add">
                                <i class="fa fa-plus-square-o"></i> <span>Add Post</span>
                                <span class="pull-right-container">
                                    <small class="label pull-right bg-green">new</small>
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="index.php?page=posts">
                                <i class="fa fa-file-word-o"></i> <span>All Posts</span>
                                <span class="pull-right-container"><?php
                    $posts = simplexml_load_file($this->data_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
                                    <small class="label pull-right bg-red"><?php echo count($total); ?></small>
                                </span>
                            </a>
                        </li>
                       
                         <li>
                            <a href="index.php?page=categories">
                                <i class="fa fa-tags"></i> <span>Catagory</span>
                                <span class="pull-right-container">
                                    <small class="label pull-right bg-purple-active"><?php
                        echo substr_count(file_get_contents('../include/categories.php'), ". ");
                        ?></small>
                                </span>
                            </a>
                        </li> <li>
                            <a href="index.php?page=chat">
                                <i class="fa fa-wechat "></i> <span>Chat</span><?php
                    $posts = simplexml_load_file($this->chat_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
                                <span class="pull-right-container">
                                    <small class="label pull-right bg-blue"><?php echo count($total); ?></small>
                                </span>
                            </a>
                        </li>
<li>
                            <a href="index.php?page=email">
                                <i class="fa fa-envelope "></i> <span>EMail</span><?php
                    $posts = simplexml_load_file($this->email_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
                                <span class="pull-right-container">
                                    <small class="label pull-right bg-blue"><?php echo count($total); ?></small>
                                </span>
                            </a>
                        </li>
                      

                       <li>
                            <a href="index.php?page=images">
                                <i class="fa  fa-file-image-o"></i> <span>Images</span>
                                <span class="pull-right-container">
                                    <small class="label pull-right bg-black-active">new</small>
                                </span>
                            </a>
                        </li> 
                       
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-gears"></i>
                                <span>Settings</span>
                                <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right text-aqua"></i>
                                </span>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="index.php?page=blog_information"><i class="fa fa-info-circle"></i> Blog Information </a></li>
                                <li><a href="index.php?page=settings"><i class="fa fa-gear"></i>Settings </a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-folder"></i> <span>Another Tool</span>
                                <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right text-olive"></i>
                                </span>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="index.php?page=sitemap"><i class="fa  fa-sitemap"></i>Sitemap </a></li>
                                
                            </ul>
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>