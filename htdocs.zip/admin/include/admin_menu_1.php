<?php
if (!defined('IN_SCRIPT'))
    die("");
?>

<?php
$this->SetAdminHeader($this->texts["config_options"]);
?>


    <?php
    $ini_array = parse_ini_file("../config.php", true);

    if (isset($_REQUEST["set_default"]) && $_REQUEST["set_default"] != "") {
        $ini_array["website"]["accent_color"] = "";
        $this->write_ini_file("../config.php", $ini_array);
    }
    $this->write_ini_file("../config.php", $ini_array);
    
    ?>
<header class="main-header">
                <!-- Logo -->
                <a href="index.php?" class="logo">
                    <!-- mini logo for sidebar mini 50x50 pixels -->
                    <span class="logo-mini"><b>A</b>LT</span>
                    <!-- logo for regular state and mobile devices -->
                    <span class="logo-lg"><b>Admin</b>LTE</span>
                </a>
                <!-- Header Navbar: style can be found in header.less -->
                <nav class="navbar navbar-static-top">
                    <!-- Sidebar toggle button-->
                    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span class="sr-only">Toggle navigation</span>
                    </a>

                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i><?php
                    $posts = simplexml_load_file($this->chat_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
              <span class="label label-success"><?php echo count($total); ?></span>
            </a>
            <ul class="dropdown-menu"><?php
                    $posts = simplexml_load_file($this->chat_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
              <li class="header">You have <?php echo count($total); ?> messages</li>	
            <div class="clearfix"></div><br> <?php
            if (!defined('IN_SCRIPT'))
                die("");
            ?>
            <?php
            $PageSize = intval($this->settings["website"]["results_per_page"]);

            if (!isset($_REQUEST["num"])) {
                $num = 1;
            } else {
                $num = $_REQUEST["num"];
                $this->ms_i($num);
            }

            $listings = simplexml_load_file($this->chat_file);

//reversing the array with the news to show the latest first
            $xml_results = array();
            foreach ($listings->listing as $xml_element)
                $xml_results[] = $xml_element;
            $xml_results = array_reverse($xml_results);
//end reversing the order of the array

            $shown_listings = 1;
            $iTotResults = 0;
            $listing_counter = sizeof($xml_results);

            foreach ($xml_results as $listing) {
                $listing_counter--;

//refine search
                if (isset($_REQUEST["only_picture"]) && $_REQUEST["only_picture"] == 1) {
                    if (trim($listing->images) == "")
                        continue;
                }

                if (isset($_REQUEST["keyword_search"]) && trim($_REQUEST["keyword_search"]) != "") {
                    if
                    (
                            stripos($listing->title, $_REQUEST["keyword_search"]) === false &&
                            stripos($listing->description, $_REQUEST["keyword_search"]) === false
                    ) {
                        continue;
                    }
                }
//end refine search


                if ($iTotResults >= ($num - 1) * $PageSize && $iTotResults < $num * $PageSize) {
                    $images = explode(",", $listing->images);

                    $strLink = $this->post_link($listing_counter, $listing->title);
                    ?>  <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu" style="width:100%">
                  <li><!-- start message -->
                    <a href="#">
                      <div class="pull-left">
                          <h5 class="text-gray"> <?php echo $listing->title; ?></h5>
                     </div> 
                          <p class="text-blue pull-right"><?php echo $this->text_words(strip_tags($listing->description1), 5); ?></p>
                      </a>
                  </li>
                  <!-- end message -->
                  
                </ul>
              </li><?php
            if ($shown_listings % 3 == 0)
                echo "<div class=\"clearfix\"></div>";
            $shown_listings++;
        }

        $iTotResults++;
    }
    ?>
              <li class="footer"><a href="index.php?page=chat">See All Messages</a></li>
            </ul>
          </li>
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-text-height"></i><?php
                    $posts = simplexml_load_file($this->data_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
              <span class="label label-success"><?php echo count($total); ?></span>
            </a>
            <ul class="dropdown-menu"><?php
                    $posts = simplexml_load_file($this->data_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
              <li class="header">You have <?php echo count($total); ?> posts</li>	
            <div class="clearfix"></div><br> <?php
            if (!defined('IN_SCRIPT'))
                die("");
            ?>
            <?php
            $PageSize = intval($this->settings["website"]["results_per_page"]);

            if (!isset($_REQUEST["num"])) {
                $num = 1;
            } else {
                $num = $_REQUEST["num"];
                $this->ms_i($num);
            }

            $listings = simplexml_load_file($this->data_file);

//reversing the array with the news to show the latest first
            $xml_results = array();
            foreach ($listings->listing as $xml_element)
                $xml_results[] = $xml_element;
            $xml_results = array_reverse($xml_results);
//end reversing the order of the array

            $shown_listings = 1;
            $iTotResults = 0;
            $listing_counter = sizeof($xml_results);

            foreach ($xml_results as $listing) {
                $listing_counter--;

//refine search
                if (isset($_REQUEST["only_picture"]) && $_REQUEST["only_picture"] == 1) {
                    if (trim($listing->images) == "")
                        continue;
                }

                if (isset($_REQUEST["keyword_search"]) && trim($_REQUEST["keyword_search"]) != "") {
                    if
                    (
                            stripos($listing->title, $_REQUEST["keyword_search"]) === false &&
                            stripos($listing->description, $_REQUEST["keyword_search"]) === false
                    ) {
                        continue;
                    }
                }
//end refine search


                if ($iTotResults >= ($num - 1) * $PageSize && $iTotResults < $num * $PageSize) {
                    $images = explode(",", $listing->images);

                    $strLink = $this->post_link($listing_counter, $listing->title);
                    ?>  <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu" style="width:100%">
                  <li><!-- start message -->
                    <a href="#">
                      <div class="pull-left">
                          <h5 class="text-gray"> <?php echo $listing->title; ?></h5>
                     </div> 
                          <p class="text-blue pull-right"><?php echo $this->text_words(strip_tags($listing->description),30);?></p>
                      </a>
                  </li>
                  <!-- end message -->
                  
                </ul>
              </li><?php
            if ($shown_listings % 3 == 0)
                echo "<div class=\"clearfix\"></div>";
            $shown_listings++;
        }

        $iTotResults++;
    }
    ?>
              <li class="footer"><a href="index.php?page=posts">See All posts</a></li>
            </ul>
          </li>
          
          
     
              
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-text-height"></i><?php
                    $posts = simplexml_load_file($this->draft_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
              <span class="label label-success"><?php echo count($total); ?></span>
            </a>
            <ul class="dropdown-menu"><?php
                    $posts = simplexml_load_file($this->draft_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
              <li class="header">You have <?php echo count($total); ?> drafts</li>	
            <div class="clearfix"></div><br> <?php
            if (!defined('IN_SCRIPT'))
                die("");
            ?>
            <?php
            $PageSize = intval($this->settings["website"]["results_per_page"]);

            if (!isset($_REQUEST["num"])) {
                $num = 1;
            } else {
                $num = $_REQUEST["num"];
                $this->ms_i($num);
            }

            $listings = simplexml_load_file($this->draft_file);

//reversing the array with the news to show the latest first
            $xml_results = array();
            foreach ($listings->listing as $xml_element)
                $xml_results[] = $xml_element;
            $xml_results = array_reverse($xml_results);
//end reversing the order of the array

            $shown_listings = 1;
            $iTotResults = 0;
            $listing_counter = sizeof($xml_results);

            foreach ($xml_results as $listing) {
                $listing_counter--;

//refine search
                if (isset($_REQUEST["only_picture"]) && $_REQUEST["only_picture"] == 1) {
                    if (trim($listing->images) == "")
                        continue;
                }

                if (isset($_REQUEST["keyword_search"]) && trim($_REQUEST["keyword_search"]) != "") {
                    if
                    (
                            stripos($listing->title, $_REQUEST["keyword_search"]) === false &&
                            stripos($listing->description, $_REQUEST["keyword_search"]) === false
                    ) {
                        continue;
                    }
                }
//end refine search


                if ($iTotResults >= ($num - 1) * $PageSize && $iTotResults < $num * $PageSize) {
                    $images = explode(",", $listing->images);

                    $strLink = $this->post_link($listing_counter, $listing->title);
                    ?>  <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu" style="width:100%">
                  <li><!-- start message -->
                    <a href="#">
                      <div class="pull-left">
                          <h5 class="text-gray"> <?php echo $listing->title; ?></h5>
                     </div> 
                          <p class="text-blue pull-right"><?php echo $this->text_words(strip_tags($listing->description),30);?></p>
                      </a>
                  </li>
                  <!-- end message -->
                  
                </ul>
              </li><?php
            if ($shown_listings % 3 == 0)
                echo "<div class=\"clearfix\"></div>";
            $shown_listings++;
        }

        $iTotResults++;
    }
    ?>
              <li class="footer"><a href="index.php?page=drafts">See All Drafts</a></li>
            </ul>
          </li>
          
          
                            <li class="dropdown user user-menu">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <img src="../dist/img/avatar04.png" alt="" class="user-image"/>

                                    <span class="hidden-xs"><?php echo $ini_array["login"]["admin_user"]; ?></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <!-- User image -->
                                    <li class="user-header">
                                        <img src="../dist/img/avatar04.png" alt="" class="img-circle"/>

                                        <p>
                                            <?php echo $ini_array["login"]["admin_user"]; ?> - Web Developer
                                        </p>
                                    </li>
                                    <!-- Menu Body -->
                                    
                                    <!-- Menu Footer-->
                                    <li class="user-footer">
                                      
                                        <div class="pull-right">
                                            <a href="logout.php?" class="btn btn-default btn-flat">Sign out</a>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            <!-- Control Sidebar Toggle Button -->
                          
                        </ul>
                    </div>
                </nav>
            </header> 
     