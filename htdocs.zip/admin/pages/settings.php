<?php
if (!defined('IN_SCRIPT'))
    die("");
?>

<?php
$this->SetAdminHeader($this->texts["config_options"]);
?>


    <?php
    $ini_array = parse_ini_file("../config.php", true);

    if (isset($_REQUEST["set_default"]) && $_REQUEST["set_default"] != "") {
        $ini_array["website"]["accent_color"] = "";
        $this->write_ini_file("../config.php", $ini_array);
    }

    if (isset($_POST["proceed_save"])) {
        $ini_array["website"]["accent_color"] = stripslashes($_POST["accent_color"]);
        $ini_array["website"]["font_name"] = stripslashes($_POST["font_name"]);
        $ini_array["website"]["font_size"] = stripslashes($_POST["font_size"]);
        $ini_array["website"]["seo_urls"] = stripslashes($_POST["seo_urls"]);
        $ini_array["website"]["date_format"] = stripslashes($_POST["date_format"]);
        $ini_array["website"]["time_zone"] = stripslashes($_POST["time_zone"]);
        $ini_array["website"]["use_captcha_images"] = stripslashes($_POST["use_captcha_images"]);

        if
        (
                trim($_POST["admin_username"]) != "" &&
                trim($_POST["old_password"]) != "" &&
                trim($_POST["new_password"]) != "" &&
                trim($_POST["confirm_new_password"]) != ""
        ) {
            $admin_password_salt = "D58X1W";
            if (trim($_POST["new_password"]) != trim($_POST["confirm_new_password"])) {
                echo "<h3>" . $this->texts["passwords_mismatch"] . "</h3>";
            } else
            if (md5($_POST["old_password"] . $admin_password_salt) != $ini_array["login"]["admin_password"]) {
                echo "<h3>" . $this->texts["old_password_wrong"] . "</h3>";
            } else {
                $ini_array["login"]["admin_password"] = md5($_POST["new_password"] . $admin_password_salt);
                $ini_array["login"]["admin_user"] = stripslashes($_POST["admin_username"]);

                echo "<h3>" . $this->texts["password_changed_success"] . "</h3>";
            }
        }

        $this->write_ini_file("../config.php", $ini_array);
    }
    ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

                <form id="main" action="index.php" method="post">
                    <a href="edit_1.php"></a>
                    <input class="input-lg form-control" type="hidden" name="page" value="settings"/>
                    <input class="input-lg form-control" type="hidden" name="proceed_save" value="1"/>

                        <legend><?php echo $this->texts["website_settings"]; ?></legend>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->texts["use_seo_urls"]; ?>:</label>

                                    <select name="seo_urls" class="form-control">
                                        <option value="0" <?php if ($ini_array["website"]["seo_urls"] == "0") echo "selected"; ?>><?php echo $this->texts["no_word"]; ?></option>
                                        <option value="1" <?php if ($ini_array["website"]["seo_urls"] == "1") echo "selected"; ?>><?php echo $this->texts["yes_word"]; ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->texts["use_captcha_images"]; ?>:</label>

                                    <select name="use_captcha_images" class="form-control">
                                        <option value="0" <?php if ($ini_array["website"]["use_captcha_images"] == "0") echo "selected"; ?>><?php echo $this->texts["no_word"]; ?></option>
                                        <option value="1" <?php if ($ini_array["website"]["use_captcha_images"] == "1") echo "selected"; ?>><?php echo $this->texts["yes_word"]; ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->texts["date_format"]; ?>:</label>

                                    <input class="input-lg form-control" type="text" name="date_format" value="<?php echo $ini_array["website"]["date_format"]; ?>"/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->texts["time_zone"]; ?>:</label>
                                    <input class="input-lg form-control" type="text" name="time_zone" value="<?php echo $ini_array["website"]["time_zone"]; ?>"/>
                                </div>
                            </div>
                        </div>


                        <legend><?php echo $this->texts["modify_admin_user_pass"]; ?></legend>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->texts["username"]; ?>:</label>

                                    <input class="input-lg form-control" type="text" name="admin_username" value="<?php echo $ini_array["login"]["admin_user"]; ?>"/>
                                </div></div></div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->texts["old_password"]; ?>:</label>

                                    <input class="input-lg form-control" type="password" name="old_password" value=""/></div></div></div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->texts["new_password"]; ?>:</label>

                                    <input class="input-lg form-control" type="password" name="new_password" value=""/></div></div></div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->texts["confirm_new_password"]; ?>:</label>

                                    <input class="input-lg form-control" type="password" name="confirm_new_password" value=""/>
                                </div>
                            </div>
                        </div>

                    <div class="clearfix"></div>
                    <br/>
                    <button type="submit" class="btn btn-primary pull-right"><?php echo $this->texts["save"]; ?></button>
                    <div class="clearfix"></div>
                </form>
    </section></div>