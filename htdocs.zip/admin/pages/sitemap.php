<?php
$show_add_form=true;
$id=0;
$xml = simplexml_load_file($this->information_file);

$this->SetAdminHeader($this->texts["texts_sitemap"]);

    ?>
<div class="panel-body">
        <a href="../../sitemap.php"><?php echo $this->texts["refresh_sitemap"];?></a></button><br>
     <a href="../../sitemap.xml"><?php echo $this->texts["view_sitemap"];?></a></button>
</div>
site map for user
<div class="panel-body">
      <a href="../../sitemap_1.php"><?php echo $this->texts["refresh_sitemap"];?></a></button><br>
     <a href="../../sitemap.html"><?php echo $this->texts["view_sitemap"];?></a></button>
</div>