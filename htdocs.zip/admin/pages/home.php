<?php
if (!defined('IN_SCRIPT'))
    die("");
?>

<?php
$this->SetAdminHeader($this->texts["dashboard"]);
?>

<div class="content">
    <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon  bg-green-active"><i class="fa fa-tags"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text"><?php echo $this->texts["blog_categories"]; ?></span>
                    <span class="info-box-number"><?php
                        echo substr_count(file_get_contents('../include/categories.php'), ". ");
                        ?></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>

        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon  bg-green-active"><i class="fa  fa-file-word-o"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text"><?php echo $this->texts["my_posts"]; ?></span><?php
                    $posts = simplexml_load_file($this->data_file);
                    $total = $posts->xpath("/listings/listing");
                    ?>
                    <span class="info-box-number"><?php echo count($total); ?></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div> 

        <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="info-box">
                <span class="info-box-icon  bg-green-active"><i class="fa fa-plus-square"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">   <p><?php echo $this->texts["new_post"]; ?></p></span>

                </div> 
                <div class="info-box-content">
                    <span class="info-box-text">   <a href="index.php?page=add"><i class="fa fa-plus-circle"></i></a></span>

                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>


    </div>
</div>

<div class="col-lg-12">
    <div class="card min-height-300">
        <br/>
        <div class="clearfix"></div>

        <div class="header">
            <h4 class="title"><?php echo $this->texts["your_current_listings"]; ?></h4>
        </div>

        <br/>
        <?php
        $listings = simplexml_load_file($this->data_file);
        $i = 0;
        $xml_results = array();
        foreach ($listings->listing as $xml_element)
            $xml_results[] = $xml_element;
        $xml_results = array_reverse($xml_results);
        $iTotResults = 0;
        $listing_counter = sizeof($xml_results);

        if ($listing_counter == 0) {
            echo "<br/><div class=\"add-padding\"><i>" . $this->texts["any_posts"] . " <a href=\"index.php?page=categories\"></a></i></div><br/><br/>";
        } else {
            ?>
            <div class="table-striped table-wrap add-padding">
                <table class="table table-striped">
                    <thead>
                        <tr>

                            <th width="80"><?php echo $this->texts["edit"]; ?></th>

                            <th width="198"><?php echo $this->texts["images"]; ?></th>

                            <th ><?php echo $this->texts["title"]; ?></th>


                            <th width="120"><?php echo $this->texts["date"]; ?></th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($xml_results as $listing) {
                            $listing_counter--;
                            if ($i >= 5)
                                break;
                            ?>
                            <tr>

                                <td><a href="index.php?page=edit&id=<?php echo $listing_counter; ?>"><img src="images/edit-icon.gif"/></a></td>

                                <td>
                                    <?php
                                    $image_ids = explode(",", $listing->images);
                                    $has_image = false;
                                    foreach ($image_ids as $image_id) {
                                        if (file_exists("../thumbnails/" . $image_id . ".jpg")) {
                                            echo "<a href=\"../uploaded_images/" . $image_id . ".jpg\" target=\"_blank\"><img src=\"../thumbnails/" . $image_id . ".jpg\" style=\"width:50px;height:50px\"/></a>";
                                            $has_image = true;
                                        }
                                    }

                                    if (!$has_image) {
                                        ?>
                                        <img src="../images/image.png"  style="width: 50px;height: 50px"/>
                                        <?php
                                    }
                                    ?>
                                </td>

                                <td>
                                    <strong><a class="underline-link" href="index.php?page=edit&id=<?php echo $listing_counter; ?>"><?php echo $listing->title;?></a></strong>
                                    <br/>
                                    <i style="font-size:11px"><?php echo $this->text_words(strip_tags($listing->description), 30); ?></i>

                                </td>


                                <td><?php echo date($this->settings["website"]["date_format"], intval($listing->time)); ?></td>



                            </tr>
                            <?php
                            $i++;
                        }
                        ?>

                    </tbody>
                </table>
            </div>
            <br/>
            <div class="col-lg-12">
                <a class="btn btn-primary" href="index.php?page=posts"><?php echo $this->texts["see_all"]; ?></a>
            </div>

            <?php
        }
        ?>

        <div class="clearfix"></div>
        <br/>



    </div>
</div>	
