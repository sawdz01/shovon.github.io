<?php
$show_add_form = true;
$id = 0;
$xml = simplexml_load_file($this->information_file);

$this->SetAdminHeader($this->texts["texts_information"]);

if (isset($_REQUEST["delete_logo"]) && $_REQUEST["delete_logo"] == 1) {
    $xml->information[$id]->blog_logo = "";
    $xml->asXML($this->information_file);

    $xml = simplexml_load_file($this->information_file);
}

if (isset($_REQUEST["delete_background"]) && $_REQUEST["delete_background"] == 1) {
    $xml->information[$id]->intro_background = "";
    $xml->asXML($this->information_file);

    $xml = simplexml_load_file($this->information_file);
}

if (isset($_POST["proceed_save"])) {

    $str_images_list = "";
    $input_field = "blog_logo";
    $limit_pictures = 1;
    $path = "../";
    include("include/images_processing.php");

    if ($str_images_list != "") {
        $xml->information[$id]->blog_logo = $str_images_list;
    }


    $xml->information[$id]->blog_logo_text = stripslashes($_POST["blog_logo_text"]);
    $xml->information[$id]->intro_content = stripslashes($_POST["intro_content"]);

    $xml->information[$id]->intro_title = stripslashes($_POST["intro_title"]);
    $xml->information[$id]->intro_text = stripslashes($_POST["intro_text"]);

    $str_images_list = "";
    $input_field = "intro_background";
    include("include/images_processing.php");

    if ($str_images_list != "") {
        $xml->information[$id]->intro_background = stripslashes($str_images_list);
    }

    $xml->information[$id]->carousal = stripslashes($_POST["carousal"]);
    $xml->information[$id]->tagline = stripslashes($_POST["tagline"]);
    $xml->information[$id]->webname = stripslashes($_POST["webname"]);
    $xml->information[$id]->script1 = stripslashes($_POST["script1"]);
    $xml->information[$id]->script2 = stripslashes($_POST["script2"]);
    $xml->information[$id]->script3 = stripslashes($_POST["script3"]);
    $xml->information[$id]->simage = stripslashes($_POST["simage"]);
    $xml->information[$id]->meta = stripslashes($_POST["meta"]);
    $xml->information[$id]->ad = stripslashes($_POST["ad"]);
    $xml->information[$id]->disclaimer = stripslashes($_POST["disclaimer"]);
    $xml->information[$id]->privacy = stripslashes($_POST["privacy"]);
    $xml->information[$id]->asn = stripslashes($_POST["asn"]);
    $xml->information[$id]->favicon = stripslashes($_POST["favicon"]);
    $xml->information[$id]->about = stripslashes($_POST["about"]);
    $xml->information[$id]->terms = stripslashes($_POST["terms"]);
    $xml->information[$id]->css = stripslashes($_POST["css"]);
    $xml->information[$id]->domainname = stripslashes($_POST["domainname"]);
    $xml->information[$id]->footer_text = stripslashes($_POST["footer_text"]);
    $xml->information[$id]->default_title = stripslashes($_POST["default_title"]);
    $xml->information[$id]->default_description = stripslashes($_POST["default_description"]);
    $xml->information[$id]->default_keywords = stripslashes($_POST["default_keywords"]);
    $xml->information[$id]->facebook_url = stripslashes($_POST["facebook_url"]);
    $xml->information[$id]->google_url = stripslashes($_POST["google_url"]);
    $xml->information[$id]->twitter_url = stripslashes($_POST["twitter_url"]);
    $xml->information[$id]->instagram_url = stripslashes($_POST["instagram_url"]);

    $xml->asXML($this->information_file);
    echo "<h3>" . $this->texts["modifications_saved"] . "</h3><br/>";

    $xml = simplexml_load_file($this->information_file);
}

if ($show_add_form) {
    ?>
    <section class="content">

        <div class="col-lg-offset-1">


            <div class="row">
                <br/>
                <form action="index.php" method="post"   enctype="multipart/form-data">
                    <input type="hidden" name="page" value="blog_information"/>
                    <input type="hidden" name="proceed_save" value="1"/>


                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["footer_text"]; ?></label>
                                <textarea rows="2" type="text" id="footer_text" name="footer_text" class="input-h form-control border-input"><?php echo $xml->information[$id]->footer_text; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Favicon</label>

    <?php
    if ($xml->information[$id]->blog_logo != "" && file_exists("../uploaded_images/" . $xml->information[$id]->blog_logo . ".jpg")) {
        ?>
                                    <div class="clearfix"></div>
                                    <a href="../uploaded_images/<?php echo $xml->information[$id]->blog_logo; ?>.jpg" target="_blank"><img src="../uploaded_images/<?php echo $xml->information[$id]->blog_logo; ?>.jpg" style="max-width:200px"/></a>
                                    <a href="index.php?page=blog_information&delete_logo=1"><img src="images/cancel.gif"/></a>
                                    <div class="clearfix"></div>
                                    <br/>
        <?php
    }
    ?>
                                <input type="file" name="blog_logo" class="form-control border-input"  value="<?php echo $xml->information[$id]->blog_logo; ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Social Image</label>

    <?php
    if ($xml->information[$id]->intro_background != "" && file_exists("../uploaded_images/" . $xml->information[$id]->intro_background . ".jpg")) {
        ?>
                                    <div class="clearfix"></div>
                                    <a href="../uploaded_images/<?php echo $xml->information[$id]->intro_background; ?>.jpg" target="_blank"><img src="../uploaded_images/<?php echo $xml->information[$id]->intro_background; ?>.jpg" style="max-width:200px"/></a>
                                    <a href="index.php?page=blog_information&delete_background=1"><img src="images/cancel.gif"/></a>
                                    <div class="clearfix"></div>
                                    <br/>
                                    <?php
                                }
                                ?>

                                <input type="file" name="intro_background" class="form-control border-input"  value="<?php echo $xml->information[$id]->intro_background; ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["default_title"]; ?></label>
                                <input type="text" name="default_title" class="form-control border-input"  value="<?php echo $xml->information[$id]->default_title; ?>">
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["default_description"]; ?></label>
                                <textarea rows="6" type="text" id="default_description" name="default_description" class="form-control border-input"><?php echo $xml->information[$id]->default_description; ?></textarea>
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["default_keywords"]; ?></label>
                                <textarea rows="6" type="text" id="default_keywords" name="default_keywords" class="form-control border-input"><?php echo $xml->information[$id]->default_keywords; ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label> <?php echo $this->texts["meta_tags"]; ?></label>
                                <textarea rows="2" type="text" id="meta" name="meta" class="input-h form-control border-input"><?php echo $xml->information[$id]->meta; ?></textarea>
                            </div>  </div></div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label> <?php echo $this->texts["website_title"]; ?></label>
                                <textarea rows="" type="text" id="webname" name="webname" class="input-h form-control border-input"><?php echo $xml->information[$id]->webname; ?></textarea>
                            </div>
                        </div>
                    </div>   <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Domain URL</label>
                                <textarea rows="" type="text" id="domainname" name="domainname" class="input-h form-control border-input"><?php echo $xml->information[$id]->domainname; ?></textarea>
                            </div>
                        </div>
                    </div>    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label> Site Tagline</label>
                                <textarea rows="" type="text" id="tagline" name="tagline" class="input-h form-control border-input"><?php echo $xml->information[$id]->tagline; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["script1"]; ?></label>
                                <textarea rows="2" type="text" id="script1" name="script1" class="input-h form-control border-input"><?php echo $xml->information[$id]->script1; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["script2"]; ?></label>
                                <textarea rows="2" type="text" id="script2" name="script2" class="input-h form-control border-input"><?php echo $xml->information[$id]->script2; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["script3"]; ?></label>
                                <textarea rows="2" type="text" id="script3" name="script3" class="input-h form-control border-input"><?php echo $xml->information[$id]->script3; ?></textarea>
                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["terms"]; ?></label>
                                <textarea rows="6" type="text" id="terms" name="terms" class="input-h form-control border-input"><?php echo $xml->information[$id]->terms; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["about"]; ?></label>
                                <textarea rows="6" type="text" id="about" name="about" class="input-h form-control border-input"><?php echo $xml->information[$id]->about; ?></textarea>
                            </div>
                        </div></div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["disclaimer"]; ?></label>
                                <textarea rows="6" type="text" id="disclaimer" name="disclaimer" class="input-h form-control border-input"><?php echo $xml->information[$id]->disclaimer; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label><?php echo $this->texts["privacy"]; ?></label>
                                <textarea rows="6" type="text" id="privacy" name="privacy" class="input-h form-control border-input"><?php echo $xml->information[$id]->privacy; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn bg-primary pull-right"><?php echo $this->texts["save"]; ?></button>

                    <div class="clearfix"></div>
                    <br/>
                    <br/>
                </form>
            </div>
        </div></section>

    <?php
}
?>