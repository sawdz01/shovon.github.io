<div class="clearfix"></div><br> <?php
            if (!defined('IN_SCRIPT'))
                die("");
            ?>
            <?php
            $PageSize = intval($this->settings["website"]["results_per_page"]);

            if (!isset($_REQUEST["num"])) {
                $num = 1;
            } else {
                $num = $_REQUEST["num"];
                $this->ms_i($num);
            }

            $listings = simplexml_load_file($this->chat_file);

//reversing the array with the news to show the latest first
            $xml_results = array();
            foreach ($listings->listing as $xml_element)
                $xml_results[] = $xml_element;
            $xml_results = array_reverse($xml_results);
//end reversing the order of the array

            $shown_listings = 1;
            $iTotResults = 0;
            $listing_counter = sizeof($xml_results);

            foreach ($xml_results as $listing) {
                $listing_counter--;

//refine search
                if (isset($_REQUEST["only_picture"]) && $_REQUEST["only_picture"] == 1) {
                    if (trim($listing->images) == "")
                        continue;
                }

                if (isset($_REQUEST["keyword_search"]) && trim($_REQUEST["keyword_search"]) != "") {
                    if
                    (
                            stripos($listing->title, $_REQUEST["keyword_search"]) === false &&
                            stripos($listing->description, $_REQUEST["keyword_search"]) === false
                    ) {
                        continue;
                    }
                }
//end refine search


                if ($iTotResults >= ($num - 1) * $PageSize && $iTotResults < $num * $PageSize) {
                    $images = explode(",", $listing->images);

                    $strLink = $this->post_link($listing_counter, $listing->title);
                    ?>
					
<div class="col-md-12">
              <ul class="timeline">
            <!-- timeline time label -->
            <li class="time-label">
                  <span class="bg-red">
                    <?php echo date($this->settings["website"]["date_format"], intval($listing->time)); ?>
                  </span>
            </li>
           
                <li>
              <i class="fa fa-envelope bg-blue"></i>

 <div class="timeline-item">
            <h4 class="time"> <?php echo $listing->title; ?></h4>

                <h3 class="timeline-header"><?php echo $listing->title; ?> sent a message</h3>

                <div class="timeline-body">
                    <h5>   <?php echo $this->text_words(strip_tags($listing->description1), 72345678976543214567839450066857650); ?></h5>
                </div>
                
              </div>
            <!-- /.box-header -->
                 </li>
              </ul>     </div>  <?php
            if ($shown_listings % 3 == 0)
                echo "<div class=\"clearfix\"></div>";
            $shown_listings++;
        }

        $iTotResults++;
    }
    ?>

<div class="col-md-12">
    <?php
    $this->Title($this->information->default_title);
    $this->MetaDescription($this->information->default_description);
    $this->MetaKeywords($this->information->default_keywords);
    ?>
    <div class="clearfix"></div>


    <?php
    $strSearchString = "";

    foreach ($_POST as $key => $value) {
        if ($key != "num" && $value != "") {
            $strSearchString .= $key . "=" . $value . "&";
        }
    }

    foreach ($_GET as $key => $value) {
        if ($key != "num" && $value != "") {
            $strSearchString .= $key . "=" . $value . "&";
        }
    }


    if (ceil($iTotResults / $PageSize) > 1) {
        echo '<nav class="navigation pagination" role="navigation">';



        $inCounter = 0;

        if ($num > 2) {
            echo "<li><a class=\"page-numbers  \" href=\"index.php?" . $strSearchString . "num=1\">First</a></li>";

            echo "<li><a class=\"page-numbers \" href=\"index.php?" . $strSearchString . "num=" . ($num - 1) . "\"> Previous</a></li>";
        }

        $iStartNumber = $num - 2;


        if ($iStartNumber < 1) {
            $iStartNumber = 1;
        }

        for ($i = $iStartNumber; $i <= ceil($iTotResults / $PageSize); $i++) {
            if ($inCounter >= 5) {
                break;
            }

            if ($i == $num) {
                echo "<li><a><b>" . $i . "</b></a></li>";
            } else {
                echo "<li><a class=\"page-numbers \" href=\"index.php?" . $strSearchString . "num=" . $i . "\">" . $i . "</a></li>";
            }


            $inCounter++;
        }

        if (($num + 1) < ceil($iTotResults / $PageSize)) {
            echo "<li><a  href=\"index.php?" . $strSearchString . "num=" . ($num + 1) . "\"> Next</b></a></li>";

            echo "<li><a href=\"index.php?" . $strSearchString . "num=" . (ceil($iTotResults / $PageSize)) . "\">Last </a></li>";
        }

        echo '</nav>';
    }



    if ($iTotResults == 0) {
        ?>
        <div class="col-md-12">
            <i><?php echo $this->texts["no_results"]; ?></i>
        </div>
        <?php
    }
    ?>                       
    
</div>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <?php
if (!defined('IN_SCRIPT'))
    die("");


$this->SetAdminHeader($this->texts["new_post"]);
?>

<div class="">
    <br/>
     <div class="clearfix"></div>  


  	

    <div class="content add-padding">

        <?php
        $show_add_form = true;

        class SimpleXMLExtended extends SimpleXMLElement {

            public function addChildWithCDATA($name, $value = NULL) {
                $new_child = $this->addChild($name);

                if ($new_child !== NULL) {
                    $node = dom_import_simplexml($new_child);
                    $no = $node->ownerDocument;
                    $node->appendChild($no->createCDATASection($value));
                }

                return $new_child;
            }

        }

        if (isset($_REQUEST["proceed_save"])) {
            ///images processing
            $str_images_list = "";
            $limit_pictures = 25;
            $path = "../";

            $ini_array = parse_ini_file("../config.php", true);
            $image_quality = $ini_array["website"]["image_quality"];
            $max_image_width = $ini_array["website"]["max_image_width"];

            include("include/images_processing.php");
            ///end images processing
            $listings = simplexml_load_file($this->chat_file, 'SimpleXMLExtended', LIBXML_NOCDATA);
            $listing = $listings->addChild('listing');
            $listing->addChild('time', time());
            $listing->addChild('blog_category', $_POST["blog_category"]);
            $listing->addChild('title', stripslashes($_POST["title"]));
            $article_content = stripslashes($_POST["description1"]);
            $article_content = str_replace("&nbsp;", " ", $article_content);

            $listing->addChildWithCDATA('description1', $article_content);
            $listing->addChild('images', $str_images_list);
            $listings->asXML($this->chat_file);
            ?>
			<a href="index.php?page=chat">
            <div class="col-md-12">
          <div class="box box-danger">
            <div class="box-header">
              <h3 class="box-title"></h3>
            </div>
            <div class="box-body">
              
            </div>
            <!-- /.box-body -->
            <!-- Loading (remove the following to stop the loading)-->
            <div class="overlay">
              <i class="fa fa-refresh fa-spin"></i>
            </div>
            <!-- end loading -->
          </div>
          <!-- /.box -->
        </div></a>
            <br/>
            <br/>
            <br/>
            <?php
            $show_add_form = false;
        }



        if ($show_add_form) {
            ?>

            <form  action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="proceed_save" value="1"/>

                <div class="row">
                    <div class="col-md-12">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->texts["name"]; ?></label>
                                    <input type="text" name="title" class="form-control border-input" required value="shovon">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->texts["description"]; ?></label>

                                    <textarea class="form-control" id="description1" name="description1" cols="40" rows="10" style="width:100%;height:100%;min-width:700px"></textarea>
                                </div>	
                            </div>
                        </div>		
                        <br>

                        <div class="clearfix"></div>


                        <div class="clearfix"></div>
                        <br/>
                        <button type="submit" class="btn btn-primary"> <?php echo $this->texts["submit"]; ?> </button>
                        <div class="clearfix"></div>
                        <br/><br/>
                        </form>


                        <?php
                    }
                    ?>
                </div>
                </div></div>